/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Kyle Post
 *
 * Created on November 30, 2017, 1:11 PM
 * Purpose: A simple application to pick a travel option from 5 options
 */

#include <stdio.h>
#include <stdlib.h>

int main () {

   /* local variable definition */
   int travel = 4;

   switch(travel) {
      case 1 :
         printf("You chose to travel to Tokyo!\n" );
         break;
      case 2 :
          printf("You chose to travel to Ontario\n" );
         break;
      case 3 :
         printf("You chose to travel to St. Petersburg!\n" );
         break;
      case 4 :
         printf("You chose to travel to Madrid\n" );
         break;
      case 5 :
         printf("You chose to stay at home\n" );
         break;
      default :
         printf("Invalid travel option\n" );
   }
   
   printf("Thank you for choosing travel option %d\n", travel);
 
   return 0;
}

