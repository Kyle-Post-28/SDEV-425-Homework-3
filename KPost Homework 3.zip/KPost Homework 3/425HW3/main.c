/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Kyle Post
 *
 * Created on November 28, 2017, 9:11 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function prototypes
void fillPassword(size_t, char[]);
void showResults(char);
// should have void listed
void showMenu(void);

// Define a variable to hold a password
// and the copy
char password[15];
//char cpassword[15];

int main(void) {
    // Welcome the User
    vprintf_s("Welcome to the C Array Program!\n");

    // Variables
    char cont = 'y'; // To continue with loop
    int ch;
    size_t n = 5;
    char* buffer;
    buffer = (char*) malloc(n * sizeof (char));
    int cVar = 0; // process variable

    if (!buffer) {
        vprintf_s("Unable to allocate memory");
        return;
    }

    // Display menu and Get Selection
    while (cont != 'E' && cont != 'e') {
        // Display the Menu
        showMenu();
        // Get the user selection
        if (getline(&buffer, &n, stdin) == -1) {
            wprintf_s("Error Unable to read characters");
        } else {
            char *p = strchr(buffer, '\n');
            if (p) {
                *p = '\0';
            }
            else {
                /* Newline not found; flush stdin to end of line */
                while ((ch = getchar()) != '\n' && ch != EOF);
                if (ch == EOF && !feof(stdin) && !ferror(stdin)) {
                    vsnprintf_s("Error: End-of-File found, no new line");
                }
            }
            cont = buffer[0];
        }
        // Display the menu response
        showResults(cont);

    }
    free(buffer);
    // Call the Copy routine	
    fillPassword(sizeof (password), password);

    // Display variable values
    printf_s("password is %s\n", password);
    printf_s("cVar is %d\n", cVar);

    // Copy password 	
    //memcpy_s(cpassword, password, sizeof (password));

    // Pause before exiting
    char confirm;
    printf_s("Confirm your exit!");
    confirm = getchar();
    return 0;
}

// Make a String of '1's

void fillPassword(size_t n, char dest[]) {
    // Should be n-1
    for (size_t j = 0; j < n - 1; j++) {
        dest[j] = '1';
    }
    // Add null terminator for string
    dest[n] = '\0';
}

/* Display the Results*/
void showResults(char value) {
    switch (value) {
        case 'F':
        case 'f':
            printf_s("Welcome to the Football season!\n");
            break;
        case 'S':
        case 's':
            printf_s("Welcome to the Soccer season!\n");
            break;
        case 'B':
        case 'b':
            printf_s("Welcome to the Baseball season!\n");
            break;
        case 'E':
        case 'e':
            printf_s("Exiting the Menu system!\n");
            break;
        default:
            printf_s("Please enter a valid selection\n");
    }

}

/* Display the Menu*/
void showMenu(void) {
    wprintf_s("Enter a selection from the following menu.\n");
    wprintf_s("B. Baseball season.\n");
    wprintf_s("F. Football season.\n");
    wprintf_s("S. Soccer season.\n");
    wprintf_s("E. Exit the system.\n");
}